#!/bin/bash

zip -r "BotSicalc.zip" * -x "BotSicalc.zip"